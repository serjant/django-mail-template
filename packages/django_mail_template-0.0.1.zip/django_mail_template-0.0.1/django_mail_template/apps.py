from django.apps import AppConfig


class DjangoMailConfig(AppConfig):
    name = 'django_mail'
